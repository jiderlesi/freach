<?php
$ip = $_POST['ip'];
$url = $_POST['url'];
$title =  $_POST['title'];
$filename = 'interview.txt';
$content = "IP:$ip|URL:$url|TITLE|$title\n";
// Make sure the file exists and is writable.
if (is_writable($filename)) {
    // We will using add mode open $filename,
    // Therefore,the file pointer will be at the beginning of the file,
    // That is the place where $content will be written when we use ferite(),
    // a indicates that the write mode is open, pointing the file pointer to the end of the file.If the file does not exist,try to creat it.
    if (!$handle = fopen($filename, 'a')) exit;
    // Write $content to our openning file.
    if (fwrite($handle, $content) === FALSE) exit;
    fclose($handle);
}