<?php
//get ip address
if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
    $onlineip = getenv('HTTP_CLIENT_IP');
} elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
    $onlineip = getenv('HTTP_X_FORWARDED_FOR');
} elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
    $onlineip = getenv('REMOTE_ADDR');
} elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
    $onlineip = $_SERVER['REMOTE_ADDR'];
}
//get url now
$URL = 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hello</title>
</head>
 
<body>
<input type="hidden" id="userIP" value="<?php echo $onlineip ?>" />
<input type="hidden" id="pageURL" value="<?php echo $URL ?>" />
</body>
</html>
<script type="text/javascript">
    t = document.getElementsByTagName('title');
    var pageTitle = t[0].innerHTML;
    //initialize ajax
function initXMLHttpClient() {
    var xmlhttp;
    try {
        xmlhttp = new XMLHttpRequest();
    } catch (e) {
        var XMLHTTP_IDS = new Array('MSXML2.XMLHTTP.5.0',
                                    'MSXML2.XMLHTTP.4.0',
                                    'MSXML2.XMLHTTP.3.0',
                                    'MSXML2.XMLHTTP',
                                    'Microsoft.XMLHTTP' );
        var success = false;
        for (var i=0;i < XMLHTTP_IDS.length && !success; i++) {
         try {
                xmlhttp = new ActiveXObject(XMLHTTP_IDS[i]);
                success = true;
              } catch (e) {}
        }
        if (!success) {
            throw new Error('Unable to create XMLHttpRequest.');
        }
    }
    return xmlhttp;
}
 
function Ajax(url,Action,Method){
    var formAction = Action;
    var formMethod = Method;
    //Implement the class XMLHttpRequest
    ajax = initXMLHttpClient();
    //open this files
    /**
        formMethod mean address And this address must be in paris,such as��
 
        <form action="action" method="GET"></form>
 
        var url = "myPost=aa&myAjax=abc&aaa=1q23";
        Then submit the data when the server is presented in array
 
    */
    ajax.open(formMethod,formAction,true);
    //The statement indicates what way to submit. which is equal to the enctype in the form attribute
    ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    //Request to the server side
    ajax.send(url);
    //Determine whether the method is complete and accept completely
    //if all right ,then alert();
    ajax.onreadystatechange = function(){
        if(ajax.readyState == 4 && ajax.status == 200){
            //alert(ajax.responseText);
        }
    }
}
var userIp = document.getElementById('userIP').value;
var userUrl = document.getElementById('pageURL').value;
url = 'ip='+userIp+'&url='+userUrl+'&title='+pageTitle;
Ajax(url, 'write.php', 'post')
</script>